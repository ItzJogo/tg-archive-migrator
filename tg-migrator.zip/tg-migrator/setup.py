#!/usr/bin/env python3
"""
setup.py — Interactive setup wizard.
Run once to configure .env file.
"""

import os
import sqlite3
from pathlib import Path


def ask(question: str, default: str = "", secret: bool = False) -> str:
    prompt = f"\n{question}"
    if default:
        prompt += f" [{default}]"
    prompt += ": "

    while True:
        try:
            ans = input(prompt).strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\nSetup cancelled.")
            exit(0)

        if not ans and default:
            return default
        if ans:
            return ans
        print("  Required field — please enter a value.")


def main() -> None:
    print()
    print("=" * 52)
    print("   Telegram Migrator — Setup")
    print("=" * 52)
    print()
    print("Ek ek karke sab puchunga — bas fill karte jao.")

    # API credentials
    print("\n─── Telegram API ──────────────────────────────")
    print("  my.telegram.org → API Development Tools")
    api_id = ask("API_ID (numbers only)")
    while not api_id.isdigit():
        print("  Numbers only please.")
        api_id = ask("API_ID")

    api_hash = ask("API_HASH (32 character string)")
    while len(api_hash) < 20:
        print("  Too short — copy from my.telegram.org")
        api_hash = ask("API_HASH")

    session = ask("Session name", default="my_session")

    # Chats
    print("\n─── Channels ──────────────────────────────────")
    print("  Format: -100XXXXXXXXXX")
    source = ask("SOURCE_CHAT (jahan se copy karna hai)")
    target = ask("TARGET_CHAT (jahan copy karna hai)")

    # Optional settings
    print("\n─── Settings (Enter = default) ────────────────")
    batch = ask("Batch size", default="100")
    while not batch.isdigit():
        print("  Numbers only.")
        batch = ask("Batch size", default="100")

    delay = ask("Delay between batches (seconds)", default="0.5")
    log_level = ask("Log level (INFO/DEBUG)", default="INFO").upper()
    if log_level not in ("INFO", "DEBUG", "WARNING", "ERROR"):
        log_level = "INFO"

    # Write .env
    env = Path(".env")
    if env.exists():
        ow = ask("\n.env already exists. Overwrite?", default="yes")
        if ow.lower() not in ("yes", "y"):
            print("Setup cancelled — .env unchanged.")
            return

    env.write_text(
        f"API_ID={api_id}\n"
        f"API_HASH={api_hash}\n"
        f"SESSION_NAME={session}\n"
        f"\n"
        f"SOURCE_CHAT={source}\n"
        f"TARGET_CHAT={target}\n"
        f"\n"
        f"BATCH_SIZE={batch}\n"
        f"DELAY={delay}\n"
        f"LOG_LEVEL={log_level}\n"
    )
    print("\n✓ .env saved!")

    # Checkpoint reset
    cp = Path("checkpoint.db")
    if cp.exists():
        r = ask("\nOld checkpoint found. Reset for fresh start?", default="no")
        if r.lower() in ("yes", "y"):
            with sqlite3.connect(cp) as db:
                db.execute("UPDATE state SET last_id=0 WHERE rowid=1")
            print("✓ Checkpoint reset.")
        else:
            print("✓ Checkpoint kept — will resume from last position.")

    print()
    print("=" * 52)
    print("  Setup complete!")
    print()
    print("  Run migration:")
    print("  python migrate.py")
    print("=" * 52)
    print()


if __name__ == "__main__":
    main()
