"""
Checkpoint — saves last migrated message ID to SQLite.
Allows resuming after interruption.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path


class Checkpoint:
    def __init__(self, path: Path = Path("checkpoint.db")):
        self.path = path
        self._init()

    def _init(self) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS state "
                "(id INTEGER PRIMARY KEY, last_id INTEGER DEFAULT 0)"
            )
            db.execute(
                "INSERT OR IGNORE INTO state(id, last_id) VALUES(1, 0)"
            )

    def load(self) -> int:
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT last_id FROM state WHERE id=1").fetchone()
            return row[0] if row else 0

    def save(self, last_id: int) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute(
                "UPDATE state SET last_id=? WHERE id=1", (last_id,)
            )

    def reset(self) -> None:
        with sqlite3.connect(self.path) as db:
            db.execute("UPDATE state SET last_id=0 WHERE id=1")

    def exists(self) -> bool:
        return self.path.exists()

    def status(self) -> int:
        return self.load()
