"""
Configuration loader.
Reads from .env file or environment variables.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


@dataclass
class Config:
    api_id: int
    api_hash: str
    session_name: str
    source_chat: int
    target_chat: int
    batch_size: int
    delay: float
    log_level: str

    @classmethod
    def load(cls) -> Config:
        missing = []

        api_id_raw = os.getenv("API_ID", "")
        api_hash = os.getenv("API_HASH", "")
        source_raw = os.getenv("SOURCE_CHAT", "")
        target_raw = os.getenv("TARGET_CHAT", "")

        if not api_id_raw:
            missing.append("API_ID")
        if not api_hash:
            missing.append("API_HASH")
        if not source_raw:
            missing.append("SOURCE_CHAT")
        if not target_raw:
            missing.append("TARGET_CHAT")

        if missing:
            raise ValueError(
                f"Missing required config: {', '.join(missing)}\n"
                "Run: python -m tg_migrator setup"
            )

        return cls(
            api_id=int(api_id_raw),
            api_hash=api_hash,
            session_name=os.getenv("SESSION_NAME", "tg_migrator_session"),
            source_chat=int(source_raw),
            target_chat=int(target_raw),
            batch_size=int(os.getenv("BATCH_SIZE", "100")),
            delay=float(os.getenv("DELAY", "0.5")),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )

    def display(self) -> None:
        print(f"  Source:     {self.source_chat}")
        print(f"  Target:     {self.target_chat}")
        print(f"  Session:    {self.session_name}")
        print(f"  Batch size: {self.batch_size}")
        print(f"  Delay:      {self.delay}s")
        print(f"  Log level:  {self.log_level}")
