"""
Core migration logic.
Forwards messages from source to target using low-level Telegram RPC.
"""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import AsyncIterator

from telethon import TelegramClient, functions
from telethon.errors import FloodWaitError, ChatAdminRequiredError
from telethon.tl.types import Message

from .checkpoint import Checkpoint
from .config import Config

log = logging.getLogger("tg_migrator")


@dataclass
class Stats:
    migrated: int = 0
    failed: int = 0
    skipped: int = 0
    floodwaits: int = 0
    failed_ids: list[int] = field(default_factory=list)

    def summary(self) -> str:
        return (
            f"Migrated: {self.migrated} | "
            f"Failed: {self.failed} | "
            f"Skipped: {self.skipped} | "
            f"FloodWaits: {self.floodwaits}"
        )


async def _forward(
    client: TelegramClient,
    src,
    tgt,
    msg_ids: list[int],
    stats: Stats,
) -> bool:
    """
    Low-level ForwardMessagesRequest.
    Returns True on success, False on permanent failure.
    Handles FloodWait automatically.
    """
    try:
        await client(functions.messages.ForwardMessagesRequest(
            from_peer=src,
            id=msg_ids,
            random_id=[random.randint(-(2**63), 2**63 - 1) for _ in msg_ids],
            to_peer=tgt,
            silent=True,
            drop_author=False,
        ))
        return True

    except FloodWaitError as e:
        stats.floodwaits += 1
        wait = e.seconds + 2
        log.warning(f"FloodWait — waiting {wait}s...")
        await asyncio.sleep(wait)
        return await _forward(client, src, tgt, msg_ids, stats)

    except ChatAdminRequiredError as e:
        log.error(
            f"Permission error on {msg_ids}: {e}\n"
            "Make sure you have post/forward rights in the target."
        )
        return False

    except Exception as e:
        log.error(f"Forward failed {msg_ids}: {type(e).__name__}: {e}")
        return False


async def _iter_messages(
    client: TelegramClient,
    src,
    offset_id: int,
) -> AsyncIterator[Message]:
    """Yield real messages in chronological order, skipping service messages."""
    async for msg in client.iter_messages(src, reverse=True, offset_id=offset_id):
        if msg.action is not None:
            # service message (join/leave/pin/etc) — skip
            continue
        yield msg


async def migrate(
    client: TelegramClient,
    config: Config,
    checkpoint: Checkpoint,
    progress_callback=None,
) -> Stats:
    """
    Main migration loop.
    Yields progress updates via progress_callback(stats, last_id).
    """
    src = await client.get_input_entity(config.source_chat)
    tgt = await client.get_input_entity(config.target_chat)

    last_id = checkpoint.load()
    log.info(f"Resuming from message ID: {last_id}")

    stats = Stats()
    batch: list[int] = []
    last_batch_id = last_id

    async for msg in _iter_messages(client, src, offset_id=last_id):
        batch.append(msg.id)
        last_batch_id = msg.id

        if len(batch) >= config.batch_size:
            ok = await _forward(client, src, tgt, batch, stats)

            if ok:
                stats.migrated += len(batch)
            else:
                # Fallback: one by one
                for mid in batch:
                    ok1 = await _forward(client, src, tgt, [mid], stats)
                    if ok1:
                        stats.migrated += 1
                    else:
                        stats.failed += 1
                        stats.failed_ids.append(mid)

            checkpoint.save(last_batch_id)

            if progress_callback:
                progress_callback(stats, last_batch_id)

            batch = []
            await asyncio.sleep(config.delay)

    # Remaining
    if batch:
        ok = await _forward(client, src, tgt, batch, stats)
        if ok:
            stats.migrated += len(batch)
        else:
            for mid in batch:
                ok1 = await _forward(client, src, tgt, [mid], stats)
                if ok1:
                    stats.migrated += 1
                else:
                    stats.failed += 1
                    stats.failed_ids.append(mid)
        checkpoint.save(last_batch_id)

    return stats


async def retry_failed(
    client: TelegramClient,
    config: Config,
    failed_ids: list[int],
) -> tuple[int, int]:
    """Retry previously failed message IDs. Returns (success, still_failed)."""
    src = await client.get_input_entity(config.source_chat)
    tgt = await client.get_input_entity(config.target_chat)
    stats = Stats()

    success = 0
    still_failed = 0

    for mid in failed_ids:
        ok = await _forward(client, src, tgt, [mid], stats)
        if ok:
            success += 1
        else:
            still_failed += 1
        await asyncio.sleep(config.delay)

    return success, still_failed
