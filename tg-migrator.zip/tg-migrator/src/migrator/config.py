"""
config.py — Load and validate configuration from .env
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


@dataclass
class Config:
    api_id:      int
    api_hash:    str
    session_name: str
    source_chat: int
    target_chat: int
    batch_size:  int
    delay:       float
    log_level:   str

    @classmethod
    def from_env(cls) -> "Config":
        errors = []

        api_id_raw = os.getenv("API_ID", "")
        if not api_id_raw.isdigit():
            errors.append("API_ID missing or invalid")

        api_hash = os.getenv("API_HASH", "")
        if not api_hash:
            errors.append("API_HASH missing")

        source_raw = os.getenv("SOURCE_CHAT", "")
        if not source_raw:
            errors.append("SOURCE_CHAT missing")

        target_raw = os.getenv("TARGET_CHAT", "")
        if not target_raw:
            errors.append("TARGET_CHAT missing")

        if errors:
            raise ValueError(
                "Config errors:\n" + "\n".join(f"  - {e}" for e in errors) +
                "\n\nRun: python setup.py"
            )

        return cls(
            api_id=int(api_id_raw),
            api_hash=api_hash,
            session_name=os.getenv("SESSION_NAME", "session"),
            source_chat=int(source_raw),
            target_chat=int(target_raw),
            batch_size=int(os.getenv("BATCH_SIZE", "100")),
            delay=float(os.getenv("DELAY", "0.5")),
            log_level=os.getenv("LOG_LEVEL", "INFO"),
        )
