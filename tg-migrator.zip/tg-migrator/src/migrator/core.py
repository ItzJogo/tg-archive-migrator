"""
core.py — Main migration engine.
Forward messages from source to target using low-level Telegram RPC.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field

from telethon import TelegramClient, functions
from telethon.errors import (
    ChatAdminRequiredError,
    FloodWaitError,
    MessageIdInvalidError,
    MsgIdInvalidError,
)

from .checkpoint import Checkpoint
from .config import Config

log = logging.getLogger("migrator.core")


# ── Stats ─────────────────────────────────────────────────────────────────────

@dataclass
class Stats:
    migrated: int = 0
    skipped:  int = 0
    failed:   int = 0
    floods:   int = 0
    started:  float = field(default_factory=time.monotonic)

    @property
    def elapsed(self) -> float:
        return max(0.001, time.monotonic() - self.started)

    @property
    def rate(self) -> float:
        total = self.migrated + self.skipped + self.failed
        return total / self.elapsed

    def summary(self) -> str:
        mins = int(self.elapsed // 60)
        secs = int(self.elapsed % 60)
        return (
            f"Migrated: {self.migrated} | "
            f"Skipped: {self.skipped} | "
            f"Failed: {self.failed} | "
            f"FloodWaits: {self.floods} | "
            f"Time: {mins}m {secs}s | "
            f"Rate: {self.rate:.1f} msg/s"
        )


# ── Forward ───────────────────────────────────────────────────────────────────

async def _forward_batch(
    client: TelegramClient,
    src,
    tgt,
    msg_ids: list[int],
    stats: Stats,
) -> bool:
    """
    Forward a list of message IDs from src to tgt.
    Uses low-level ForwardMessagesRequest directly.
    Returns True on success.
    """
    try:
        await client(functions.messages.ForwardMessagesRequest(
            from_peer=src,
            id=msg_ids,
            random_id=[random.randint(-(2**63), 2**63 - 1) for _ in msg_ids],
            to_peer=tgt,
            silent=True,
            drop_author=False,
        ))
        return True

    except FloodWaitError as e:
        stats.floods += 1
        wait = e.seconds + 3
        log.warning(f"FloodWait — sleeping {wait}s")
        await asyncio.sleep(wait)
        return await _forward_batch(client, src, tgt, msg_ids, stats)

    except (MessageIdInvalidError, MsgIdInvalidError):
        log.warning(f"Invalid message IDs {msg_ids} — skipping")
        return False

    except ChatAdminRequiredError as e:
        log.error(f"Permission error: {e}")
        raise

    except Exception as e:
        log.error(f"Forward failed {msg_ids}: {type(e).__name__}: {e}")
        return False


async def _forward_one_by_one(
    client: TelegramClient,
    src,
    tgt,
    msg_ids: list[int],
    stats: Stats,
    delay: float,
) -> None:
    """Fallback: forward one message at a time when batch fails."""
    for mid in msg_ids:
        ok = await _forward_batch(client, src, tgt, [mid], stats)
        if ok:
            stats.migrated += 1
        else:
            stats.failed += 1
            log.warning(f"Skipped message {mid}")
        await asyncio.sleep(delay)


# ── Main engine ───────────────────────────────────────────────────────────────

async def run(config: Config, checkpoint: Checkpoint) -> Stats:
    stats = Stats()

    async with TelegramClient(
        config.session_name,
        config.api_id,
        config.api_hash,
    ) as client:

        log.info("Connected to Telegram")

        src = await client.get_input_entity(config.source_chat)
        tgt = await client.get_input_entity(config.target_chat)

        src_info = await client.get_entity(config.source_chat)
        tgt_info = await client.get_entity(config.target_chat)
        log.info(f"Source: {getattr(src_info, 'title', src_info)}")
        log.info(f"Target: {getattr(tgt_info, 'title', tgt_info)}")

        last_id = checkpoint.load()
        log.info(f"Resuming from message ID: {last_id}")

        batch: list[int] = []
        last_msg_id = last_id

        async for msg in client.iter_messages(
            src,
            reverse=True,
            offset_id=last_id,
        ):
            # Skip service messages
            if msg.action is not None:
                stats.skipped += 1
                checkpoint.save(msg.id)
                continue

            # Skip empty deleted messages
            if msg.message is None and msg.media is None:
                stats.skipped += 1
                checkpoint.save(msg.id)
                continue

            batch.append(msg.id)
            last_msg_id = msg.id

            if len(batch) >= config.batch_size:
                ok = await _forward_batch(client, src, tgt, batch, stats)
                if ok:
                    stats.migrated += len(batch)
                    log.info(
                        f"[{stats.migrated}] Batch forwarded "
                        f"(IDs {batch[0]}–{batch[-1]}) | "
                        f"Rate: {stats.rate:.1f}/s"
                    )
                else:
                    log.warning(f"Batch failed — retrying one by one")
                    await _forward_one_by_one(
                        client, src, tgt, batch, stats, config.delay
                    )

                checkpoint.save(last_msg_id)
                batch = []
                await asyncio.sleep(config.delay)

        # Remaining
        if batch:
            ok = await _forward_batch(client, src, tgt, batch, stats)
            if ok:
                stats.migrated += len(batch)
                log.info(f"[{stats.migrated}] Final batch forwarded")
            else:
                await _forward_one_by_one(
                    client, src, tgt, batch, stats, config.delay
                )
            checkpoint.save(last_msg_id)

    return stats
