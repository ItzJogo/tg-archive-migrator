#!/usr/bin/env python3
"""
reset.py — Reset checkpoint for fresh migration start.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from migrator import Checkpoint

cp = Checkpoint()
confirm = input("Reset checkpoint? Fresh start hoga. (yes/no): ").strip().lower()
if confirm in ("yes", "y"):
    cp.reset()
else:
    print("Cancelled.")
