# Telegram Channel Migrator

Simple, clean tool to migrate messages between Telegram channels.

## Features

- Forward messages using native Telegram API
- Auto resume from where you stopped
- FloodWait handled automatically
- Batch forwarding for speed
- One-by-one fallback if batch fails
- Service messages skipped automatically

## Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Configure
python setup.py

# Run
python migrate.py
```

## Other Commands

```bash
# Reset checkpoint (fresh start)
python reset.py

# Stop migration
Ctrl + C   (progress is saved automatically)
```

## .env Reference

```
API_ID=your_api_id
API_HASH=your_api_hash
SESSION_NAME=my_session

SOURCE_CHAT=-100xxxxxxxxxx
TARGET_CHAT=-100xxxxxxxxxx

BATCH_SIZE=100
DELAY=0.5
LOG_LEVEL=INFO
```

Get API credentials from: https://my.telegram.org
