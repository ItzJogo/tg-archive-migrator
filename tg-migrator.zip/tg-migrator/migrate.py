#!/usr/bin/env python3
"""
migrate.py — Run the migration.
"""

import asyncio
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from migrator import Config, Checkpoint, run


def setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )


async def main() -> None:
    try:
        config = Config.from_env()
    except ValueError as e:
        print(f"\n{e}\n")
        sys.exit(1)

    setup_logging(config.log_level)
    log = __import__("logging").getLogger("migrator")

    checkpoint = Checkpoint()

    log.info("Starting migration...")
    log.info(f"Source: {config.source_chat}")
    log.info(f"Target: {config.target_chat}")
    log.info(f"Batch size: {config.batch_size}")

    try:
        stats = await run(config, checkpoint)
    except KeyboardInterrupt:
        log.info("Stopped by user — progress saved.")
        return
    except Exception as e:
        log.error(f"Fatal error: {e}")
        raise

    print()
    print("=" * 52)
    print("  Migration Complete!")
    print(f"  {stats.summary()}")
    print("=" * 52)


if __name__ == "__main__":
    asyncio.run(main())
